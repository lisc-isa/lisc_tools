WRITE_RD(sext_xlen(( (insn.u_imm() >> 1) + (pc >> 1) ) << 1) );
