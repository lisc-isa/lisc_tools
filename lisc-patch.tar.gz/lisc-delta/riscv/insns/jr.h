set_pc( RS1 + insn.i_imm() );

